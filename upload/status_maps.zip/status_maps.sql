-----------------------------------------------------------------------------
-- BEGIN - QUERIES USED FOR AQUATIC RANGE STATUS PROJECT - NOV - DEC 2013
-----------------------------------------------------------------------------
-- File name: Any SpatiaLite database (e.g. db.sqlite)
-- Author: Greg Krakow
-- Date: 12/04/2013
-- Purpose: Use the year from last observation or collection date to
-- derive age classes of 5 year increments from the present year for
-- delimited management units.

-- Note: Requires input_locations1.txt (1 or more files) and mgt_units.shp (4 files).
-- The shapefile and lat/lon in the input text files need to be in WGS84 coordinate reference system units.
-- Input file must be a tab delimited text file, without a header row. 
-- Input file fields must be in this order: name, data_source, unique_id, date, year, latitude, longitude
-- mgt_units.shp should have a field named "mu_code" containing unique management unit code.

-- Load management units shapefile
.loadshp mgt_units mgt_units CP1252 4326

-- Create data table named "input" with the point data to process.
CREATE TABLE input (sname CHAR, datasource CHAR, unique_id CHAR, date CHAR, year CHAR, lat CHAR, lon CHAR);
.separator "\t"
.import input_locations1.txt input
-- To append additional data to input, uncomment next line.
--.import input_locations2.txt input


-- ***************************************************
-- Make points from lat and lon (epsg:4326).
CREATE TABLE query1_point AS

SELECT sname
    ,datasource
    ,unique_id
    ,"date"
    ,"year"
    ,pointfromtext('POINT (' || lon || ' ' || lat || ')', 4326) AS Geometry
FROM input

-- #####################################
-- Limit returned results for testing
--Limit 100
-- #####################################
;

-- *************************************************** --
-- Create a field showing years from present year that the taxon was last observed.
CREATE TABLE query2_sinceobs AS

SELECT sname
    ,datasource
    ,unique_id
    ,"date"
    ,"year"
    ,CASE
        -- Filter out bad values for year
        -- Bad values will be given a value of 8 (unknown) in next query.
        WHEN "year" IS NOT NULL
        AND YEAR > 1700
        AND YEAR < 3000
            THEN strftime('%Y', 'now') - "year"
        ELSE 
            NULL
        END AS sinceobs
    ,Geometry
FROM query1_point
WHERE Geometry IS NOT NULL
;

-- ***************************************************
-- Create age classes from year
CREATE TABLE query3_age_class AS

SELECT ROWID
    ,sname
    ,datasource
    ,unique_id
    ,"date"
    ,"year"
    ,sinceobs
    ,CASE
        WHEN YEAR IS NULL
            THEN 6 -- Unknown
        WHEN (UPPER("YEAR") LIKE '%PRE%')
            AND (year <= 20)
            THEN 6 -- Unknown
        WHEN (UPPER("YEAR") LIKE '%PRE%')
            AND (year > 20)
            THEN 5 -- Over 20 years
        WHEN sinceobs > 20
            THEN 5
        WHEN sinceobs > 15
            THEN 4
        WHEN sinceobs > 10
            THEN 3
        WHEN sinceobs > 5
            THEN 2
        WHEN sinceobs <= 5
            THEN 1
        ELSE 6 -- null or Unknown
        END age_class
    ,Geometry
FROM query2_sinceobs
;

-- Recover geometry and build spatial index
SELECT RecoverGeometryColumn('query3_age_class', 'Geometry', 4326, 'POINT', 2);
SELECT CreateSpatialIndex('query3_age_class', 'geometry')
;

-- ***************************************************
-- Add the management unit code to the list of input locations.
-- Derived from points intersecting management unit polygon.
CREATE TABLE query4_mgt_units AS

SELECT sname
    ,datasource
    ,unique_id
    ,"date"
    ,"year"
    ,sinceobs
    ,age_class
    ,mu_code
FROM query3_age_class AS c
    ,mgt_units AS m
WHERE Intersects(c.Geometry, m.Geometry)
    -- spatial index follows
       AND c.ROWID IN (
       SELECT pkid
       FROM idx_query3_age_class_Geometry
       WHERE xmin > MbrMinX(m.Geometry)
           AND xmax < MbrMaxX(m.Geometry)
           AND ymin > MbrMinY(m.Geometry)
           AND ymax < MbrMaxY(m.Geometry)
       )
;

-- ***************************************************
-- Query aggregating the least age class by sname and management unit.
CREATE TABLE query5_aggregate AS

SELECT sname
    ,mu_code
    ,MIN(age_class) AS age_class
FROM query4_mgt_units
GROUP BY sname
    ,mu_code
ORDER BY sname
    ,mu_code
;

-- ***************************************************
-- Join aggregate data to associated features to make spatial table
CREATE TABLE query6_feature_join AS
SELECT sname
	,a.mu_code
	,age_class
	,Geometry
FROM query5_aggregate AS a
	,mgt_units AS m
WHERE a.mu_code = m.mu_code
;

-- Recover geometry column so that output shapefile will have a prj, projection file
SELECT RecoverGeometryColumn('query6_feature_join', 'Geometry', 4326, 'POLYGON', 2);
;

-- ***************************************************
-- Output feature join table as shapefile
.dumpshp query6_feature_join Geometry output_status CP1252 POLYGON


-- ***************************************************
-- Export result tables as tab delimited text files
.headers on
.mode tabs

.output output4qc.txt
select * from query4_mgt_units;

.output output.txt
select * from query5_aggregate;
